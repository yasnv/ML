# A Machine Learning Web Application to predict the quality of wine
- Code witten in python
- model trainned with AutoML using TPOT
- web application built with Streamlit 
- Application Hosted on Heroku 
All the dependences can be found in the requirements.txt 

App link hosted on streamlit team: https://s4a.streamlit.io/opeyemibami/wine-quality-prediction-web-app/master/app.py/+/

App link on heroku: https://wine-quality-web-app.herokuapp.com/

## Read detailed project article published with [FritzAi/Heartbeat](https://heartbeat.fritz.ai/building-a-conversational-chatbot-with-nltk-and-tensorflow-part-1-f452ce1756e5)
